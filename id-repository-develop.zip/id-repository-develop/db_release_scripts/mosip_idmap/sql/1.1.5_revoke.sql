-- -------------------------------------------------------------------------------------------------
-- Database Name: mosip_idmap
-- Release Version 	: 1.1.5
-- Purpose    		: Revoking Database Alter deployement done for release in ID Map DB.       
-- Create By   		: Ram Bhatt
-- Created Date		: Jan-2021
-- 
-- Modified Date        Modified By         Comments / Remarks
-- -------------------------------------------------------------------------------------------------

\c mosip_idmap sysadmin
