-- -------------------------------------------------------------------------------------------------
-- Database Name: mosip_idmap
-- Release Version 	: 1.1.2
-- Purpose    		: Revoking Database Alter deployement done for release in ID Map DB.       
-- Create By   		: Sadanandegowda DM
-- Created Date		: Sep-2020
-- 
-- Modified Date        Modified By         Comments / Remarks
-- -------------------------------------------------------------------------------------------------

\c mosip_idmap sysadmin