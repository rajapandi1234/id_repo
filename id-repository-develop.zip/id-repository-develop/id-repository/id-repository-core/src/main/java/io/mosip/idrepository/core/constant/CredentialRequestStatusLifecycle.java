package io.mosip.idrepository.core.constant;

/**
 * @author Manoj SP
 * @author Nagarjuna
 *
 */
public enum CredentialRequestStatusLifecycle {
	NEW, REQUESTED, FAILED, DELETED, INVALID;
}
