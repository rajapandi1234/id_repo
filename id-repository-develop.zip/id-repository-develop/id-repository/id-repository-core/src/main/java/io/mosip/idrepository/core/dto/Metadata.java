package io.mosip.idrepository.core.dto;

public class Metadata {

}
