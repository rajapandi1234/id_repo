package io.mosip.idrepository.core.constant;

public interface EventType {

}
