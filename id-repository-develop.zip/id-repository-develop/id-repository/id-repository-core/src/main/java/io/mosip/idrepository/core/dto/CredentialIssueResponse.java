package io.mosip.idrepository.core.dto;

import lombok.Data;

@Data
public class CredentialIssueResponse {

	private String requestId;
	private String id;
}
