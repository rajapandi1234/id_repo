# ID Repository Core

## Overview

ID Repository core contains all common classes used across all ID Repository modules and other modules integrating with ID Repository.