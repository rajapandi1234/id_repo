# Credential Service

## Overview
Refer [here](https://docs.mosip.io/1.2.0/modules/id-repository#credential-service)

## Default context-path and port
Refer [`bootstrap.properties`](src/main/resources/bootstrap.properties)
