package io.mosip.credentialstore.dto;

public class PartnerGetCertificateResponseDto extends PartnerResponseWrapper<PartnerCertDownloadResponeDto>{

}
