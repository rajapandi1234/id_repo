package io.mosip.credentialstore.dto;

import lombok.Data;

@Data
public class Issuer {

	private String code;
	private String name;
}
