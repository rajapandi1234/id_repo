package io.mosip.credentialstore.constants;

public enum LoggerFileConstant {
	SESSIONID, ID, REQUEST_ID
}
