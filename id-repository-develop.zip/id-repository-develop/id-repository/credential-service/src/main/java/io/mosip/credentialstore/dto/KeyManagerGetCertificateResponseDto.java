package io.mosip.credentialstore.dto;

import io.mosip.kernel.core.http.ResponseWrapper;


public class KeyManagerGetCertificateResponseDto extends ResponseWrapper<KeyPairGenerateResponseDto> {

}
