package io.mosip.credentialstore.dto;

import lombok.Data;

@Data
public class Extractor {
	private String provider;

	private String version;
}
