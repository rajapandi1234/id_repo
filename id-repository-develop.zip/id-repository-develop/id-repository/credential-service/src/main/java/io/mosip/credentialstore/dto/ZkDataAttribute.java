package io.mosip.credentialstore.dto;

import lombok.Data;

@Data
public class ZkDataAttribute {

	private String identifier;
	
	private String value;
}
