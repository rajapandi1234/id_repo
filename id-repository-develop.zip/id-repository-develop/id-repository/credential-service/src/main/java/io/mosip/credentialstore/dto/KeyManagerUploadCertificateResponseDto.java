package io.mosip.credentialstore.dto;

import io.mosip.kernel.core.http.ResponseWrapper;

public class KeyManagerUploadCertificateResponseDto extends ResponseWrapper<UploadCertificateResponseDto>{

}
