# Credential Request Generator

## Overview
Refer [here](https://docs.mosip.io/1.2.0/modules/id-repository#credential-request-generator)

## Default context-path and port
Refer [`bootstrap.properties`](src/main/resources/bootstrap.properties)
