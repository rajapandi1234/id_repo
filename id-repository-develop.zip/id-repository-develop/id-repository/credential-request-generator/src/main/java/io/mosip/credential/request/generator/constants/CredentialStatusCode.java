package io.mosip.credential.request.generator.constants;

/**
 * 
 * @author Sowmya
 *
 */
public enum CredentialStatusCode {
	NEW, CANCELLED, ISSUED, FAILED, RETRY;
}
