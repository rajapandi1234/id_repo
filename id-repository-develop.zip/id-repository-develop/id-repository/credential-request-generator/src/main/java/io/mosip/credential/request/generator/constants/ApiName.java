package io.mosip.credential.request.generator.constants;

/**
 * 
 * @author Sowmya
 *
 */
public enum ApiName {

	CRDENTIALSERVICE,
	ENCRYPTION,
	DECRYPTION;

}
