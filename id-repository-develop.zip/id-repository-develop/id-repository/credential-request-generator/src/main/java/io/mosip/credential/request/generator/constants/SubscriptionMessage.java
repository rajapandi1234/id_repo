package io.mosip.credential.request.generator.constants;

public class SubscriptionMessage {
	public static final String SUCCESS = "Success";
    public static final String ALREADY_SUBSCRIBED = "Already Subscribed";
}