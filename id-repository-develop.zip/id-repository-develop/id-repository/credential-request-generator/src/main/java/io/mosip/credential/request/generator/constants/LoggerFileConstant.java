package io.mosip.credential.request.generator.constants;

public enum LoggerFileConstant {
	SESSIONID, ID, REQUEST_ID
}
