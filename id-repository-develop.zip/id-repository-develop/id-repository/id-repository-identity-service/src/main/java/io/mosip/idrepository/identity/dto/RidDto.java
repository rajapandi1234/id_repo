package io.mosip.idrepository.identity.dto;

import lombok.Data;

/**
 * The Get RID dto.
 * 
 * @author Ritik Jain
 */
@Data
public class RidDto {

	private String rid;

}
