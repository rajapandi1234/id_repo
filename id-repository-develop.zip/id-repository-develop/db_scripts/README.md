# Databases

## Overview
This folder containers various SQL scripts to create database and tables in postgres. The tables are described under `<db name>/ddl/`. Default data that's populated in the tables is present under `<db name>/dml` folder 

This folder containers various SQL scripts to create database and tables in postgres.  These scripts are automatically run with as part of DB initialisation in [Sandbox Deployment](https://docs.mosip.io/1.2.0/deployment/sandbox-deployment) 

Developers may run the SQLs using `<db name>/deploy.sh` script.

