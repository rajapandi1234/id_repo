drop role if exists idrepouser; 
