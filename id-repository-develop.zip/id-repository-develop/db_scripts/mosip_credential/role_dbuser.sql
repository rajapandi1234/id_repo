CREATE ROLE credentialuser WITH 
	INHERIT
	LOGIN
	PASSWORD :dbuserpwd;
