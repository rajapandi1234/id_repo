\c mosip_credential

\ir ddl/credential-credential_transaction.sql
\ir ddl/credential-batch_job_execution.sql
\ir ddl/credential-batch_job_execution_context.sql
\ir ddl/credential-batch_job_execution_params.sql
\ir ddl/credential-batch_job_instance.sql
\ir ddl/credential-batch_step_execution.sql
\ir ddl/credential-batch_step_execution_context.sql
\ir ddl/credential-fk.sql
