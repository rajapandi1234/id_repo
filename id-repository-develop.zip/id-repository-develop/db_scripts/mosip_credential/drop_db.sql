DROP DATABASE IF EXISTS mosip_credential;

