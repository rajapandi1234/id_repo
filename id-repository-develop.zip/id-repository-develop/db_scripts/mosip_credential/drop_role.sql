drop role if exists credentialuser;
