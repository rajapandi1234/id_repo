\c mosip_idmap 

\ir ddl/idmap-vid.sql
\ir ddl/idmap-vid_seed.sql
\ir ddl/idmap-vid_seq.sql
\ir ddl/idmap-uin_hash_salt.sql
\ir ddl/idmap-uin_encrypt_salt.sql

