drop role if exists idmapuser; 
